# paypal_integration_carding
paypal pro integration for carding(cc cashout ) I am not responsible for your actions

recharge your paypal account with a bank card


# extract the " vendor.zip file "

open 

charge.php

set your paypal infos


HAPPY CARDING

# demo youtube

https://youtu.be/c8Lk9vVB8_g



hakanonymos@hotmail.com

instagram : hakanonymos
